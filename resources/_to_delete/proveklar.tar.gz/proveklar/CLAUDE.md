# Prøveklar — Danish study hub

A single-page study tool for Chris's Danish course: **Danish to Go 3**, chapters 1–2,
cross-referenced with his **Studieskolen modul 3.3** class notes.

Published as a Claude Artifact at:
**https://claude.ai/code/artifact/5bcabe74-e2ff-4b2e-bf70-6e3e96b237cb**

## Build

```bash
python3 build.py
```

No dependencies. Writes `dist/index.html` (body-only, for republishing as an Artifact)
and `dist/standalone.html` (a complete HTML document you can open from disk).

To preview: `python3 -m http.server` then open `dist/standalone.html`.
Open it over http rather than `file://` — `localStorage` is blocked on `file://`
in Chrome, and the progress tracking silently does nothing.

## Layout

```
src/hub.html      markup, CSS and all page logic. Contains a /*DATA*/ marker
                  that build.py replaces with the concatenated data modules.
src/words1.js     chapter 1 vocabulary   -> WORDS, TIERS, CATS
src/words2.js     chapter 2 vocabulary   -> WORDS_CH2
src/rules.js      grammar                -> RULE_GROUPS, RULES
src/verbs.js      conjugations           -> VERBS
src/listen.js     listening + oral       -> LISTENING, ORAL
src/practice.js   drills + writing tasks -> SETS, WRITING
source/           the two PDFs this was built from
dist/             build output — do not edit by hand
```

The page has six tabs: Status, Grammatik, Verber, Ord, Lyt & tal, Øv dig.

## Data shapes

**Word** (`words1.js`, `words2.js`)
```js
{da:"at lære", en:"to learn; to teach", c:"verb", t:1, p:4, n:"optional note"}
```
- `c` — one of `verb phrase noun adj adv time pron`
- `t` — usefulness tier 1–4 (1 = learn first, 4 = recognise only). Tiers are a
  judgement about real-world frequency, not something the book states.
- `p` — printed page in *Danish to Go 3*. These match the PDF and the paper book.

**Rule** (`rules.js`)
```js
{g:"verbs", src:"both", ref:"Notes · Book p.33", title:"…",
 rule:"…", table:[["label","value"]], ex:["…"], trap:"…", star:true}
```
- `g` — must match an `id` in `RULE_GROUPS`, or the card renders nowhere.
- `src` — `both` (book **and** class notes — highest test probability),
  `notes`, or `book`. Drives the coloured tag.
- `star` — priority. Star rules also get a `★` prefix in `title` and are
  weighted double in the readiness score.
- `rule`, `table` values, `ex` and `trap` all accept inline HTML. Everything
  else is escaped.

**Verb** (`verbs.js`)
```js
{i:"at lære", n:"lærer", d:"lærte", f:"har lært", m:"lær",
 e:"to learn; to teach", grp:"2", src:"book"}
```
- `i n d f m` = infinitiv, nutid, datid, førnutid, imperativ. `–` for none.
- `grp` — `1` (-ede), `2` (-te), `U` (irregular), `M` (modal).
- `src` — `sheet` (from `source/verbs.pdf`, **transcribed verbatim, do not
  "correct"**) or `book`.

**Drill set** (`practice.js`)
```js
{id:"tense", name:"…", rule:"verbs", intro:"…",
 items:[{q:"Jeg ___ (flytte) …", a:"flyttede", w:"why"}]}
```
`w` accepts HTML. Answers with more than one right form are written as
`"der / som"` and the `w` says so.

## Progress tracking — read before renaming anything

Progress lives in the viewer's browser only. Two keys:

| Key | Holds |
|---|---|
| `dtg3-k1-v1` | ticked words (`known`), plus the words-tab toggles |
| `dtg3-hub-v1` | marked rules, marked verbs, drill scores, active tab, last-marked date |

**These are keyed by content strings, not ids:**

- words by `da`
- rules by `title`
- verbs by `i`
- drills by `setId + ':' + index`

So editing a word's `da`, a rule's `title`, a verb's `i`, or reordering the
items inside a drill set **orphans that entry's saved progress**. Adding new
entries is always safe. If you must rename, bump the storage key and accept the
reset, or write a migration in the boot block at the bottom of `hub.html`.

The readiness percentage on the Status tab is weighted: grammar 30 % (half of
that the ★ rules), words 25 % (tier 1–2 only), drills 25 %, verbs 20 %. It is
self-reported — it counts what has been marked, not what is known. The page
says so, and it should keep saying so.

## Adding chapter 3

1. Add `src/words3.js` exporting `WORDS_CH3`, same shape and same four tiers.
2. Add it to `MODULES` in `build.py` and to the merge line in `hub.html`
   (`const ALL_WORDS = …`).
3. Add a `ch3` chip to `wFilters` in `hub.html`.
4. Append to `RULES`, `VERBS`, `LISTENING`, `ORAL`, `SETS` as needed — those
   render straight from the arrays and need no other change.
5. Update the masthead eyebrow (`Kapitel 1–2`) and the lede.

## Republishing

`dist/index.html` is the file to publish. It is deliberately **body-only** — no
doctype, `<html>`, `<head>` or `<body>` tags — because the Artifact runtime
wraps it. Publishing it needs a Claude session that has the Artifact tool, and
the existing URL must be passed explicitly or a second artifact gets created
instead of updating this one.

`dist/standalone.html` is the same page as a complete document, for local use.

## House rules

- Danish content is checked before it ships. Every form in `verbs.js` marked
  `src:"sheet"` was diffed against `source/verbs.pdf` programmatically; the
  rest was reviewed against Retskrivningsordbogen. Keep that bar.
- Examples come from the book or the class notes wherever possible, not
  invented. Where a drill mirrors a book exercise, the `w` note says which page
  and where the book's own answer key is.
- Both colour themes are token-driven in `:root`, `@media (prefers-color-scheme: dark)`
  guarded with `:root:not([data-theme="light"])`, and `:root[data-theme="dark"]`.
  Never declare a colour only inside a media or `[data-theme]` block.
- `.bar` is the toolbar class and `.pbar` is the progress bar. They collided
  once; don't reintroduce that.
