#!/usr/bin/env python3
"""Build the Prøveklar study hub.

    python3 build.py

Concatenates the data modules into src/hub.html at the /*DATA*/ marker and
writes two outputs:

    dist/index.html      body-only, for publishing as a Claude Artifact
    dist/standalone.html full HTML document, for opening from disk

Order matters: words1 and words2 must come before the rest, because hub.html's
script merges them at load time.
"""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
SRC = ROOT / "src"
DIST = ROOT / "dist"

MODULES = [
    "words1.js",    # chapter 1 vocabulary  -> WORDS, TIERS, CATS
    "words2.js",    # chapter 2 vocabulary  -> WORDS_CH2
    "rules.js",     # grammar               -> RULE_GROUPS, RULES
    "verbs.js",     # conjugations          -> VERBS
    "listen.js",    # listening + oral      -> LISTENING, ORAL
    "practice.js",  # drills + writing      -> SETS, WRITING
]


def main() -> int:
    shell = (SRC / "hub.html").read_text(encoding="utf-8")
    if "/*DATA*/" not in shell:
        print("error: src/hub.html has lost its /*DATA*/ marker", file=sys.stderr)
        return 1

    data = "\n".join((SRC / m).read_text(encoding="utf-8") for m in MODULES)
    body = shell.replace("/*DATA*/", data)

    DIST.mkdir(exist_ok=True)
    (DIST / "index.html").write_text(body, encoding="utf-8")

    head, rest = body.split("<style>", 1)
    style, tail = rest.split("</style>", 1)
    doc = (
        '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
        + head
        + "<style>"
        + style
        + "</style>\n</head>\n<body>\n"
        + tail
        + "\n</body>\n</html>\n"
    )
    (DIST / "standalone.html").write_text(doc, encoding="utf-8")

    print(f"dist/index.html      {len(body):>7,} bytes")
    print(f"dist/standalone.html {len(doc):>7,} bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
